/** \file IDataStream.h
*
*  This header defines the APIs that can be used by clients for creating and
*  using EnergyTrace data streams. 
*
*  Copyright (c) 2015-2018, Texas Instruments Inc., All rights reserved.
*/

#ifndef GTI_CALLBACKS_DATA_STREAM_H
#define GTI_CALLBACKS_DATA_STREAM_H

/*! \mainpage EnergyTrace MainPage
*
* \section intro_sec Introduction
*
* EnergyTrace is a proprietory Texas Instruments technology that allows
* streaming energy and/or digital information off chip to enable profiling
* energy consumption patterns on most SimpleLink MCU targets. This information
* can be vital to customers for optimizing the energy consumption and analyzing
* battery life.
*
* The following sections describe the technology and the supported devices in
* detail.
*
* \subsection EnergyTrace A. EnergyTrace Analog measurement Technology
* 
* TI has 2 kinds of EnergyTrace analog measurement technology. 
*  -#   <b>EnergyTrace MSP (ET-MSP):</b>
*       The ET-MSP hardware measures energy consumtion of the target and based
*       the energy data is used to derive current consumption. Due to the
*       nature of the hardware circuit this technology gives highly accurate
*       energy consumption and static currents but does not provide accurate
*       dynamic current consumption. The data rate is 2k 32-bit samples/sec
*       and the current measurement range extends from 0 to 100 mA. However
*       this solution is extremely low cost making it attractive for TI's low
*       cost and low power MCU targets such as MSP.
*  -#   <b>EnergyTrace High Dynamic Range (ETHDR):</b>
*       The ETHDR hardware measures current drop to derive current consumption
*       of the target. Due to the nature of the hardware this technology gives
*       highly accurate instantaneous current and overall energy consumption
*       with a high data rate of 256k 32-bit samples per second. This solution
*       offers 2 statically selectable modes:
*       - Low Range High Accuracy: With this option, the measurement has
*       higher accuracy but current measurement is from 0 to 120 mA.
*       - High Range Low Accuracy: With this option, the measurement has
*       lower accuracy than the other mode. However the range extends from
*       0 to 800 mA.
*       This solution is slighly more expensive than ET-MSP but its high
*       sampling range characteristic make it better suited for TI's
*       connectivity MCU devices like the CC13/26/32xx family.
*       .
*
* \subsection Devices B. Supported Devices
*
* The APIs in this document support EnergyTrace with the <b>XDS110 Debug Probe</b>
* only with SimpleLink devices that have a single <b>Cortex M</b> core. Different
* XDS110 based devices support different modes of capture which include digital
* state information. The details of the level of support are defined below:
*
* <table>
* <tr> <th> Hardware                                                    <th> EnergyTrace techology         <th> Supported Mode
* <tr> <td> MSP432P4x launchpad                                         <td>  ET-MSP                       <td>  Energy-only, Energy + Digital State (PC and power state - active or low power)
* <tr> <td> CC26x0/13x0 launchpad                                       <td>  <i>(No EnergyTrace circuit)</i>   <td>  Digital State - only  (PC and peripehral state)
* <tr> <td> CC26x2/13x2 launchpad                                       <td>  ET-HDR (low range)           <td>  Energy-only , Energy + Digital State (PC and peripehral state)
* <tr> <td> Standalone XDS110 Debug Probe                               <td>  ET-MSP                       <td>  Energy-only , Energy + Digital State (Target specific)
* <tr> <td> Standalone XDS110 Debug Probe with ETHDR Add-on             <td>  ETHDR (low and high range)   <td>  Energy-only , Energy + Digital State (Target specific)
* <tr> <td> All other XDS110 based launchpads (eg. CC32xx, MSP432E4x)   <td>  Not supported                <td>  Not supported
* </table>
*
* \subsection Emupack C. Supported Emupack
*
* The features/modes and functionality explained in this documents are from emupack 7.0.48.0 onwards.
*/

/*! \page Started Getting Started
*
*  This section describes the mechanism to integrate EnergyTrace solution.
*
* \section Prerequisites A. Prerequisites
*
* -# Please read the MainPage for information on supported devices.
* -# The details described here assume that the EnergyTrace mechanism is being
*    integrated while using TI Emulation Cortex M driver library.
* -# The implementation requiures knowledge of the GTI APIs. The
*    details of this can be found in the GTI_API documenation.
* -# Requires the minimum supported emupack listed in Introduction.
* -# When using the GTI APIs the target connection is made via board configuration files.
*    Sample board configuration files can be found in the board_config folder in the
*    package.
*
*<hr>
*
* \section Hardware B. Special hardware handling
*
* \subsection XDS110-Pod 1. Standalone XDS110 Debug Probe with/without ETHDR Add-on
*
* TI has a Standalone XDS110 Probe which also supports EnergyTrace as indicated in the Introduction.
* EnergyTrace measurements require that the XDS110 probe supply power to the target. This is
* done by default for launchpads with on-board XDS110 and so they do not require any special handling.
* However for the Standalone XDS110, the supply needs to be setup explicitly. The details for this
* are listed here:
*
* \subsubsection Hardware-Setup 1a. Standalone XDS110 Probe Hardware Setup
*
* The documentation on the hardware setup for EnergyTrace can be found in the following User's Guides:
* -# XDS110 Debug Probe User's Guide: http://www.ti.com/lit/ug/sprui94/sprui94.pdf
* -# ETHDR Add-On User's Guide: http://www.ti.com/lit/ug/spruie1a/spruie1a.pdf
*
*
* \subsubsection Boardconfig 1b. Board configuration file setup
*
* The information that XDS110 must supply power and the voltage level of the supply is provided to the
* emulation stack via the board configuration file. The Standalone XDS110 can supply power with a voltage
* range of 1.8V to 3.6V. See the example board config file named "MSP432_XDS110_SWD_PROBE_POWER.dat".
* The following lines in the first section of the board config file convey the supply information as
* probe supplied power at 3.3V. These lines must exist as specified in the sample board
* config file if the XDS110 standalone probe is to supply power for EnergyTrace.
*
* \code
* pod_supply=1
* pod_voltage_selection=1
* pod_voltage=3.3
* \endcode
*
* The client can make the power supply information as a user configuration. Depending on the
* selection the board config file can be modified as below:
*
* -# User configures - XDS110 with Target supplied power (self-powered)
* <br>
* Example: MSP432_XDS110_SWD_SELF_POWER.dat
*    \code
* pod_supply=0
* pod_voltage_selection=0
* pod_voltage=0
* \endcode    
* -# User configures - XDS110 with Probe supplied power of voltage <x_volts>
* <br>
* Example: MSP432_XDS110_SWD_PROBE_POWER.dat
*    \code
* pod_supply=1
* pod_voltage_selection=1
* pod_voltage=<x_vols>
* \endcode    
*
* \note
* If the target has a fixed voltage level that does not change then the board configuration with the
* supply voltage settings enabled to the fixed voltage level can be used for all of the 3 scenarios:
* -# Launchpad with on-board XDS110 (the emulation stack ignores the supply settings for launchpads).
* -# XDS110 Standalone debug probe with self-powered launchpad (JTAG connection only between standalone XDS110 and target).
* -# XDS110 Standalone debug probe powering the launchpad (JTAG and supply connections between standalone XDS110 and target).
*
* <br>
* \subsection CC-Dig-state 2. CC26/13xx digital state (ET++)
*
* The digital state scanning is only available when using 4-pin cJTAG protocol. If the target is
* configured for 2-pin cJTAG protocol then on starting EnergyTrace as described in section 2c. below
* the client will be notified with an error message
* <i>"ET++ (digital state scanning) is NOT supported with 2-pin cJTAG protocol. Please change target configuration to 4-pin cJTAG protocol"</i>
*
*<hr>
*
* \section Known-Issues C. Known Issues
* None
*
*<hr>
*
* \section Changes D. Changes
* None
*
*<hr>
*
* \section Implementation-Details E. Implementation Details
*
* \subsection Step1 Step 1: Create EnergyTrace factory handle
*
* \par
* Once the client connects to the Cortex M core via the GTI_CONNECT API call,
* the client can call the GTI_QUERY_INTERFACE API to get the EnergyTrace data
* stream factory handle. The factory handle returned is an instance of the
* class GTICallbacks::IDataStreamFactory.
*
* \par
* <b>GTI_QUERY_INTERFACE</b>
* <br>
* <br>
* Input Parameter List:
* <br>
* <br>
* <table>
* <tr> <th> Parameter          <th> Description                                  <th> Value From Client                <th> Successful return from GTI driver       <th> Failed return from GTI driver
* <tr> <td> hpid               <td>  [in] GTI API instance handle                <td> (GTI handle passed in by client) <td> NA                                      <td> NA
* <tr> <td> feature_name       <td>  [in]  Requested feature name.               <td>  "GTIDataStreamFactory"          <td> NA                                      <td> NA
* <tr> <td> version            <td>  [in]  Requested feature version             <td>  1                               <td> NA                                      <td> NA
* <tr> <td> feature_handle     <td>  [out] Function pointer to the feature.      <td>  (pointer passed in by client)   <td>  GTICallbacks::IDataStreamFactory handle (non-null)   <td>  no handle (null)
* <tr> <td> supported_version  <td>  [out] Feature version supported.            <td>  (pointer passed in by client)   <td>  EnergyTrace feature version (1)        <td>  EnergyTrace feature version (0)
* <tr> <td> error              <td>  [out] Reason for error return.              <td>  (pointer passed in by client)   <td>  EnergyTrace error (0)                  <td>  EnergyTrace error (0)
* <tr> <td> obj_inst           <td>  [out] Object instance to use with feature.  <td>  (pointer passed in by client)   <td>  unused (null)                          <td>  unused (null)
* </table>
* <br>
* Return Code:
* <br>
* <br>
* <table>
* <tr> <th> Return code        <th> Description               <th> Successful return from GTI driver <th> Failed return from GTI driver
* <tr> <td> GTI_RETURN_TYPE    <td>  [out] Return code        <td> 0                                 <td> -1
* </table>
*
* \par
* If the GTICallbacks::IDataStreamFactory handle returned is a null or the Return code
* then EnergyTrace is NOT supported by the target.
* \par
* If the GTICallbacks::IDataStreamFactory handle is non-null and Return code is 0 then the
* target supports at least one of the following types of EnergyTrace modes:
* \par
* -# Energy + DigitalState
* -# Energy-only
* -# DigitalState-only
* \par
* The supported mode can be determined by using the GTICallbacks::IDataStreamFactory handle
* to create a stream handle of the given mode. If the stream creation succeeds
* then the mode is supported else the mode is not supported. Stream creation,
* getting data, destruction etc is explained in detail in the next section.
*
* <br>
* \subsection Step2 Step 2: Create EnergyTrace data stream
*
* \par
* The GTICallbacks::IDataStreamFactory::CreateDataStream API can be used to create a stream
* handle. The client can request the stream to be created with certain
* properties using the <b>pSetupData</b> parameter.
* If the stream creation succeeds, it returns a non-null instance of class
* GTICallbacks::IDataStream as well as returns Notification callbacks. The
* IDataNotification callback is used to send the EnergyTrace data from the
* target to the client. If there is any error during the time the stream is
* valid, then the error is sent to the client via the
* GTICallbacks::IErrorNotification callback.
* <br>
* <br>
* <b>2a. pSetupData</b>
* <br>
* <br>
* The pSetupData parameter is expected to be a datastructure of unsigned
* integer array of 5 elements specifying the properties of the stream
* the client wishes to create. The client needs to pass this in to the API
* as a char * pointer.
* <br>
* The elements in the setup array are as below:
* <br>
* <table>
* <tr> <th> Element            <th> Description                       <th> Possible values
* <tr> <td> unsigned int [0]   <td>  Stream Mode                      <td>     0 : Energy-only \n 1 : DigitalState-only \n 2 : Energy + DigitalState
* <tr> <td> unsigned int [1]   <td>  Deprecated                       <td>     Unused
* <tr> <td> unsigned int [2]   <td>  Deprecated                       <td>     Unused
* <tr> <td> unsigned int [3]   <td>  Stream Range                     <td>     0 : Low Range \n 1 : High Range \n <i>NOTE : This field is only used when ETHDR Add-On is used with XDS110 Standalone Probe. \n     For launchpads and base XDS110 Standalone Probe with ET-MSP, this field is ignored as these don't support 2 ranges.</i>
* </table>
* <br>
* <b>2b. IDataNotification </b>
* <br>
* <br>
* Once a valid data stream is created via the GTICallbacks::IDataStreamFactory::CreateDataStream
* API, the driver uses the IDataNotification instance passed in by the client to
* push out EnergyTrace data. This is done via the IDataNotification::OnData callback.
* The client can read the EnergyTrace data via this callback.
* \n
* \n
* The data received by the client has the following format:
* \n
* <table>
* <tr> <th> EnergyTrace Mode           <th> Packet Size (nBufferSize)   <th> Description (pBuffer)
* <tr> <td> Energy-Only                <td> 18 bytes                    <td> byte[0]     : 1-byte header ID (value is 8 for this mode) \n
*                                                                            byte[1:7]   : 7-bytes of timestamp in uSec \n
*                                                                            byte[8:11]  : 4-bytes of current in nA units \n
*                                                                            byte[12:13] : 2-bytes of voltage in mV units \n
*                                                                            byte[14:17] : 4-bytes of energy in 0.1 uJ units \n
* <tr> <td> Energy + DigitalState <td> 26 bytes                    <td> byte[0]     : 1-byte header ID (value is 7 for this mode) \n
*                                                                            byte[1:7]   : 7-bytes of timestamp in uSec \n
*                                                                            byte[8:15]  : 8-bytes of digital state (interpretation is device dependent) \n
*                                                                            byte[16:19] : 4-bytes of current in nA units \n
*                                                                            byte[20:21] : 2-bytes of voltage in mV units \n
*                                                                            byte[22:25] : 4-bytes of energy in 0.1 uJ units \n
* <tr> <td> DigitalState-only          <td> 26 bytes                    <td> byte[0]     : 1-byte header ID (value is 7 for this mode) \n
*                                                                            byte[1:7]   : 7-bytes of timestamp in uSec \n
*                                                                            byte[8:15]  : 8-bytes of digital state (interpretation is device dependent) \n
*                                                                            byte[16:19] : 4-bytes of current in nA units (value always 0 for this mode as there is no analog data) \n
*                                                                            byte[20:21] : 2-bytes of voltage in mV units (value always 0 for this mode as there is no analog data) \n
*                                                                            byte[22:25] : 4-bytes of energy in 0.1 uJ units (value always 0 for this mode as there is no analog data) \n
*
* </table>
* <br>
* <br>
* <b>2c. IErrorNotification</b>
* <br>
* <br>
* The GTICallbacks::IErrorNotification::OnError API is called by the driver when an error
* needs to be reported to the client.
*
* <br>
* \subsection Step3 Step 3: Destroy EnergyTrace data stream
*
* \par
* Once the client is done using the data stream it should destroy it using
* the GTICallbacks::IDataStream::Disable API. Once this API is called, the
* stream must never be used again.
*
*<hr>
*
* \section DataRate F. Client Data Rate Requirement
*
* Depending on the EnergyTrace analog technology and Mode being used, the
* data throughput at the client will vary. The table below indicates the
* data handling capacity of the client required for each of the modes:
*
* <table>
* <tr> <th> Hardware                                                    <th>  EnergyTrace techology   <th> Mode                   <th> Data Rate
* <tr> <td rowspan="2"> MSP432P4x launchpad                             <td rowspan="2">  ET-MSP      <td> Energy-only            <td> 2K sampling * 18 bytes = 36 Kbytes/sec
* <tr>                                                                                                <td> Energy + DigitalState  <td> 2K sampling * 26 bytes = 52 Kbytes/sec
* <tr> <td rowspan="2"> CC26x2/13x2 launchpad                           <td rowspan="2">  ETHDR       <td> Energy-only            <td> 256K sampling * 18 bytes = 4.6 Mbytes/sec
* <tr>                                                                                                <td> Energy + DigitalState  <td> 256K sampling * 26 bytes = 6.65 Mbytes/sec
* <tr> <td>             CC26x0/13x0 launchpad                           <td>  No Analog Hardware      <td> DigitalState-only      <td> 256K sampling * 26 bytes = 6.65 Mbytes/sec
* <tr> <td rowspan="2"> Standalone XDS110 Debug Probe (Base only)       <td rowspan="2">  ET-MSP      <td> Energy-only            <td> 2K sampling * 18 bytes = 36 Kbytes/sec
* <tr>                                                                                                <td> Energy + DigitalState  <td> 2K sampling * 26 bytes = 52 Kbytes/sec
* <tr> <td rowspan="2"> Standalone XDS110 Debug Probe with ETHDR Add-on <td rowspan="2">  ETHDR       <td> Energy-only            <td> 256K sampling * 18 bytes = 4.6 Mbytes/sec
* <tr>                                                                                                <td> Energy + DigitalState  <td> 256K sampling * 26 bytes = 6.65 Mbytes/sec
* </table>
*
*\n
*\n
*/

namespace GTICallbacks
{
    class IDataNotification
    {
    public:

        /*! OnData() - Called to indicate new data is available.
        *
        * This function is used to push data to the client.
        * This function should be implemented thread safe.
        *
        * \param pBuffer       [out]  Stream data packet to client.
        * \param nBufferSize   [out]  Size of stream data packet.
        *
        * \return None
        */
        virtual void OnData(const unsigned char* pBuffer, unsigned int nBufferSize) = 0;

    protected:
        inline ~IDataNotification() {}
    };

    class IErrorNotification
    {
    public:

        /*! OnError() - Called whenever an error on the stream needs to be reported.

        * This function is used to notify the client of an error. The error string
        * contains the details of the error. It will be reported to clients of the
        * stream only after all the earlier data has been consumed.
        *
        * \param pszErrorText  [out]  Error message to client.
        *
        * \return None
        */

        virtual void OnError(const char* pszErrorText) = 0;

    protected:
        inline ~IErrorNotification() {}
    };

    class IDataStream
    {
    public:

        /*! Disable() - Disables an existing data stream.
        *
        * This function is called by the client to disable/delete an existing
        * stream. Errors disabling can be pushed to the error notification
        * interface, but no further calls should be made on the interfaces
        * after this is called.  It is not safe to call this function more than
        * once.
        *
        * \param None
        *
        * \return None
        */
        virtual void Disable() = 0;

    protected:
        inline virtual ~IDataStream() {}
    };

    class IDataStreamFactory
    {
    public:

        /*! CreateDataStream() - Creates a stream according to the specified setup data.
        *
        * If the stream cannot be created, null is returned and the explanation is
        * pushed to the error notification interface.  The stream setup data
        * is target and driver specific and is known to clients and
        * implementations only.
        *
        * \param pSetupData     [in]  Stream property specified by client.
        * \param onData,        [in]  Data callback instance from client.
        * \param onError)       [in]  Error callback instance client.
        *
        * \return non-null IDataStream handle on succcess,
        *         null                        on failure
        */

        virtual IDataStream* CreateDataStream(
            const unsigned char* pSetupData,
            IDataNotification& onData,
            IErrorNotification& onError) = 0;

    protected:
        inline virtual ~IDataStreamFactory() {};
    };

}

#endif // GTI_CALLBACKS_DATA_STREAM_H
